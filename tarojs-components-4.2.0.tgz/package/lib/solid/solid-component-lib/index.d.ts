export { createSolidComponent } from './createComponent';
