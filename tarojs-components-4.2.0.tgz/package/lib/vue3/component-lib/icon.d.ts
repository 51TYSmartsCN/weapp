declare const _default: {
    emits: string[];
    setup(__props: any, { slots, emit, attrs }: {
        slots: any;
        emit: any;
        attrs: any;
    }): () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
};
export default _default;
