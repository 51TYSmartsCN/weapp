/**
 * https://github.com/BBKolton/reactify-wc/
 * modified event naming
 **/
import React from 'react';
declare const reactifyWebComponent: (WC: any) => React.ForwardRefExoticComponent<React.RefAttributes<unknown>>;
export default reactifyWebComponent;
